export const access = "public";
export const methods = ["POST"];
export default async function(req,res){res.status(410).json({error:"Creative history is not enabled in this demo build."});}
CREATE TABLE creatives (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  title TEXT NOT NULL,
  platform TEXT NOT NULL,
  objective TEXT NOT NULL,
  audience TEXT,
  offer TEXT,
  tone TEXT,
  copy_json JSONB NOT NULL,
  image_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
)
import { ai } from "hatchable";
export const access = "public";
const inventory = [
 {item:"Cheese",stock:"1.2 kg",forecast:"2.5 kg tomorrow",risk:"stockout",action:"BUY around 1.5 kg"},
 {item:"Tomatoes",stock:"12 kg",forecast:"7 kg used before expiry",risk:"expiry",action:"REDUCE next purchase and PROMOTE tomato dishes"},
 {item:"Cream",stock:"4 L",forecast:"2.2 L used before expiry",risk:"expiry",action:"USE first; excess about 1.8 L"},
 {item:"Chicken",stock:"18 kg",forecast:"16 kg tomorrow",risk:"low",action:"MAINTAIN"},
 {item:"Paneer",stock:"7 kg",forecast:"8.5 kg tomorrow",risk:"medium",action:"BUY around 2 kg"}
];
export default async function(req,res){
 const q=(req.body?.question||"").toString().trim().slice(0,4000);
 if(!q)return res.status(400).json({error:"question is required"});
 const dataset={
  inventory,
  monthlyWasteEstimate:"₹18,400",
  wasteSimulator:"At a 40% avoidable-waste scenario, the illustrative potential avoidable waste is ₹7,360 per month, or ₹88,320 annualized.",
  coreActions:["BUY","USE","REDUCE","PROMOTE"]
 };
 const system=`You are ZeroPlate, an AI-powered predictive inventory intelligence assistant for local mid-sized restaurants. Answer the user's custom question using ONLY the supplied demo dataset and clearly label any calculation or assumption as illustrative. Be practical and concise. You can answer questions about current stock, forecast demand, stockout risk, expiry risk, BUY/USE/REDUCE/PROMOTE actions, waste-to-savings, and comparisons within the dataset. If the user asks for information not contained in the dataset, say that the demo dataset does not contain that information rather than inventing it. Explain the reasoning behind recommendations when possible. Do not claim that demo figures are real restaurant results.`;
 const prompt=`Demo dataset:\n${JSON.stringify(dataset,null,2)}\n\nUser question:\n${q}`;
 try{
  const out=await ai.generateText({model:"sonnet",system,prompt,maxSteps:3,purpose:"zeroplate-custom-assistant"});
  return res.json({answer:out.text||"I could not generate an answer for that question."});
 }catch(e){
  // Keep the prototype usable even when the project's external AI provider
  // key is missing or invalid. The fallback answers only from the same demo
  // dataset; it never invents restaurant data.
  const lower=q.toLowerCase();
  let answer;
  if(lower.includes("expire") || lower.includes("expiry") || lower.includes("waste")){
    answer="The main expiry risks in the demo dataset are Tomatoes and Cream. Tomatoes: 12 kg in stock, with about 7 kg forecast to be used before expiry on 5 Oct, leaving about 5 kg exposed. Cream: 4 L in stock, with about 2.2 L forecast to be used before expiry on 4 Oct, leaving about 1.8 L. Recommended actions: REDUCE the next tomato purchase, PROMOTE tomato dishes, and USE cream first.";
  } else if(lower.includes("buy") || lower.includes("purchase") || lower.includes("order")){
    answer="The highest-priority purchase in the demo dataset is Cheese: 1.2 kg in stock versus 2.5 kg forecast demand tomorrow, implying about a 1.3 kg shortage. The demo recommendation is to BUY around 1.5 kg. Paneer is another purchase candidate: 7 kg in stock versus 8.5 kg forecast demand, so BUY around 2 kg.";
  } else if(lower.includes("risk") || lower.includes("shortage") || lower.includes("stockout")){
    answer="The biggest immediate stockout risk in the demo dataset is Cheese: 1.2 kg current stock versus 2.5 kg forecast demand tomorrow. The recommended action is BUY around 1.5 kg. Paneer has a medium risk with 7 kg in stock versus 8.5 kg forecast demand.";
  } else if(lower.includes("saving") || lower.includes("financial") || lower.includes("money") || lower.includes("₹") || lower.includes("rs")){
    answer="The Waste-to-Savings Simulator uses an illustrative monthly waste estimate of ₹18,400. At a 40% avoidable-waste scenario, the illustrative potential avoidable waste is ₹7,360 per month, or ₹88,320 annualized. These are demo calculations, not guaranteed savings.";
  } else if(lower.includes("tomato")){
    answer="Tomatoes: 12 kg in stock, with about 7 kg forecast to be used before expiry on 5 Oct. The demo flags expiry risk and recommends REDUCE the next purchase and PROMOTE tomato dishes.";
  } else if(lower.includes("cream")){
    answer="Cream: 4 L in stock, with about 2.2 L forecast to be used before expiry on 4 Oct. About 1.8 L is exposed in the demo scenario, so the recommended action is USE first.";
  } else if(lower.includes("cheese")){
    answer="Cheese: 1.2 kg in stock versus 2.5 kg forecast demand tomorrow. The demo identifies a stockout risk and recommends BUY around 1.5 kg.";
  } else {
    answer="Using the ZeroPlate demo dataset: Cheese has a high stockout risk; Paneer has medium stockout risk; Tomatoes and Cream have expiry risk; Chicken is low risk. The main actions are BUY for Cheese/Paneer, USE Cream first, REDUCE the next tomato purchase, and PROMOTE tomato dishes. For exact AI-generated reasoning, connect a valid AI provider in Hatchable Settings.";
  }
  return res.json({answer,mode:"demo-fallback",aiProviderError:"The configured AI provider rejected the request, so this answer uses the fixed ZeroPlate demo dataset."});
 }
}
export const access = "public";
export const methods = ["POST"];
export default async function(req,res){res.status(410).json({error:"This creative generator is no longer part of the ZeroPlate prototype."});}